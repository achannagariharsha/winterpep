package com.example.HealthApp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
